Thanks for using Laundry Web Service. The accelereometer_sketch.ino file is the sketch to be installed in your arduino for the Laundry Web service program. 

It works with any arduino compatible (analog) ADXL3xx accelerometer

The output is written on a virtual serial port created by Arduino driver.

 Circuit configuration:
 analog 0: accelerometer self test
 analog 1: z-axis
 analog 2: y-axis
 analog 3: x-axis
 analog 4: ground
 analog 5: vcc


Installation:
Open the sketch using Arduino program and upload it to your arduino. 

Based on sketch by David A. Mellis(2 Jul 2008). Modified by Bidit Sharma (25 Apr. 2016) for Laundry Web Service Project. 